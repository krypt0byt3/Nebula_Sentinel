// src/secrets_scan/mod.rs — Runtime secrets and credential scanning
//
// Scans files, environment variables, and process memory for exposed credentials.
// Catches what IaC scanning misses: secrets deployed at runtime, not in source.

use crate::types::{ThreatEvent, Severity, ResponseAction};
use chrono::Utc;
use regex::Regex;
use tracing::warn;
use uuid::Uuid;

/// A secret pattern to search for
pub struct SecretPattern {
    pub name:      &'static str,
    pub pattern:   &'static str,
    pub technique: &'static str,
    pub severity:  Severity,
}

pub fn default_patterns() -> Vec<SecretPattern> {
    vec![
        SecretPattern {
            name: "AWS Access Key",
            pattern: "AKIA[0-9A-Z]{16}",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "AWS Secret Key",
            pattern: "aws_secret_access_key\\s*=\\s*[A-Za-z0-9/+=]{40}",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "GitHub Token",
            pattern: "ghp_[A-Za-z0-9]{36}",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "GitHub App Token",
            pattern: "ghs_[A-Za-z0-9]{36}",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "Anthropic API Key",
            pattern: "sk-ant-[A-Za-z0-9\\-]{40,}",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "OpenAI API Key",
            pattern: "sk-[A-Za-z0-9]{48}",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "RSA Private Key",
            pattern: "-----BEGIN RSA PRIVATE KEY-----",
            technique: "T1552.004",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "EC Private Key",
            pattern: "-----BEGIN EC PRIVATE KEY-----",
            technique: "T1552.004",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "Private Key (generic)",
            pattern: "-----BEGIN PRIVATE KEY-----",
            technique: "T1552.004",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "Password in env",
            pattern: "(?i)(password|passwd|pwd)\\s*=\\s*[^\\s'\"]{6,}",
            technique: "T1552.001",
            severity: Severity::High,
        },
        SecretPattern {
            name: "Database URL",
            pattern: "(mysql|postgres|mongodb|redis)://[^:]+:[^@]+@",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
        SecretPattern {
            name: "Slack Token",
            pattern: "xox[baprs]-[0-9A-Za-z\\-]{10,}",
            technique: "T1552.001",
            severity: Severity::High,
        },
        SecretPattern {
            name: "JWT Token",
            pattern: "eyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}",
            technique: "T1552.001",
            severity: Severity::Medium,
        },
        SecretPattern {
            name: "Google API Key",
            pattern: "AIza[0-9A-Za-z_\\-]{35}",
            technique: "T1552.001",
            severity: Severity::High,
        },
        SecretPattern {
            name: "Azure SAS Token",
            pattern: "sv=[0-9]{4}-[0-9]{2}-[0-9]{2}&.*sig=",
            technique: "T1552.001",
            severity: Severity::High,
        },
        SecretPattern {
            name: "Stripe Secret Key",
            pattern: "sk_live_[0-9A-Za-z]{24}",
            technique: "T1552.001",
            severity: Severity::Critical,
        },
    ]
}

pub struct SecretsScanner {
    agent_id: String,
    hostname: String,
    patterns: Vec<(SecretPattern, Regex)>,
}

impl SecretsScanner {
    pub fn new(agent_id: &str, hostname: &str) -> Self {
        let compiled = default_patterns().into_iter()
            .filter_map(|p| {
                Regex::new(p.pattern).ok().map(|re| (p, re))
            })
            .collect();
        Self { agent_id: agent_id.to_string(), hostname: hostname.to_string(), patterns: compiled }
    }

    /// Scan environment variables of all running processes
    pub async fn scan_process_envs(&self) -> Vec<ThreatEvent> {
        let mut threats = vec![];
        let Ok(procs) = std::fs::read_dir("/proc") else { return threats };

        for entry in procs.flatten() {
            let name = entry.file_name();
            let pid_str = name.to_string_lossy();
            let Ok(pid) = pid_str.parse::<u32>() else { continue };

            let env_path = format!("/proc/{}/environ", pid);
            let Ok(env_data) = std::fs::read(&env_path) else { continue };
            let env_str = String::from_utf8_lossy(&env_data);

            let proc_name = std::fs::read_to_string(format!("/proc/{}/comm", pid))
                .unwrap_or_default().trim().to_string();

            for (pattern, re) in &self.patterns {
                if re.is_match(&env_str) {
                    warn!("🔑 Secret found in pid={} ({}) env: {}", pid, proc_name, pattern.name);
                    threats.push(self.make_secret_threat(
                        pattern,
                        format!("Process environment variable — pid={} ({})", pid, proc_name),
                        format!("{} found in environment variables of process {} (pid={}). Process environment is readable via /proc/{}/environ by any process with read access.", pattern.name, proc_name, pid, pid),
                    ));
                    break; // one alert per process per pattern
                }
            }
        }
        threats
    }

    /// Scan a specific file for secrets
    pub fn scan_file(&self, path: &str) -> Vec<ThreatEvent> {
        let mut threats = vec![];

        // Skip binary files, large files, and excluded paths
        if is_binary_path(path) || is_excluded_path(path) { return threats; }

        let Ok(content) = std::fs::read_to_string(path) else { return threats };
        if content.len() > 10_000_000 { return threats; } // skip files > 10MB

        for (pattern, re) in &self.patterns {
            if re.is_match(&content) {
                warn!("🔑 Secret found in file {}: {}", path, pattern.name);
                threats.push(self.make_secret_threat(
                    pattern,
                    format!("{} in {}", pattern.name, path),
                    format!("{} detected in file {}. This credential should be rotated immediately and removed from the file.", pattern.name, path),
                ));
            }
        }
        threats
    }

    /// Scan common credential file locations
    pub async fn scan_credential_locations(&self) -> Vec<ThreatEvent> {
        let locations = [
            "/root/.aws/credentials",
            "/root/.aws/config",
            "/home/*/.aws/credentials",
            "/etc/environment",
            "/etc/.env",
            "/.env",
            "/opt/app/.env",
            "/var/www/.env",
            "/app/.env",
            "/srv/.env",
        ];

        let mut threats = vec![];
        for loc in &locations {
            if loc.contains('*') {
                // Expand glob-like patterns
                if let Ok(entries) = std::fs::read_dir("/home") {
                    for entry in entries.flatten() {
                        let p = entry.path().join(".aws/credentials");
                        if p.exists() {
                            threats.extend(self.scan_file(&p.to_string_lossy()));
                        }
                    }
                }
            } else if std::path::Path::new(loc).exists() {
                threats.extend(self.scan_file(loc));
            }
        }
        threats
    }

    fn make_secret_threat(&self, pattern: &SecretPattern, name: String, desc: String) -> ThreatEvent {
        ThreatEvent {
            id: Uuid::new_v4().to_string(),
            agent_id: self.agent_id.clone(), hostname: self.hostname.clone(),
            timestamp: Utc::now(),
            severity:  pattern.severity.clone(),
            confidence: 90.0,
            threat_name: name, description: desc,
            mitre_tactics:    vec!["credential_access".to_string()],
            mitre_techniques: vec![pattern.technique.to_string()],
            matched_rules:    vec!["secrets_scanner".to_string()],
            raw_event_ids: vec![], chain: None, iocs: vec![],
            suggested_action: ResponseAction::Alert,
            llm_analysis: None, auto_generated_rule: None,
        }
    }
}

fn is_binary_path(path: &str) -> bool {
    let binary_exts = [".so", ".o", ".a", ".elf", ".bin", ".pyc", ".class", ".jar",
        ".png", ".jpg", ".gif", ".zip", ".gz", ".tar", ".db", ".sqlite"];
    binary_exts.iter().any(|e| path.ends_with(e))
}

fn is_excluded_path(path: &str) -> bool {
    let excluded = ["/proc/", "/sys/", "/dev/", "/run/", "/tmp/.mount"];
    excluded.iter().any(|e| path.starts_with(e))
}
