# NebulaSentinel Agent — Model Guide

The agent uses embedded llama.cpp (via the `llama_cpp` Rust crate).
The model loads directly into the agent's process memory at startup.
No separate server process. No network socket.

## Recommended models

### CPU / low-VRAM (default)

**Phi-3.5-mini-instruct Q4_K_M** — 2.4 GB
Best choice for structured JSON output and MITRE ATT&CK classification at 3.8B.
Microsoft built this specifically for reasoning in constrained contexts.
Outperforms Mistral 7B on structured output tasks despite being half the size.

```bash
nebula-agent --download-model
# OR manually:
mkdir -p /var/lib/nebula/models
curl -L -o /var/lib/nebula/models/Phi-3.5-mini-instruct-Q4_K_M.gguf \
  https://huggingface.co/bartowski/Phi-3.5-mini-instruct-GGUF/resolve/main/Phi-3.5-mini-instruct-Q4_K_M.gguf
```

### GPU with 5+ GB VRAM

**Qwen2.5-7B-Instruct Q4_K_M** — 4.7 GB (needs ~5 GB VRAM)
Current best open-weight 7B for structured output and security reasoning.
Significantly better than Mistral 7B for JSON generation and rule synthesis.
Fits in 5 GB VRAM with room for the context window.

```bash
curl -L -o /var/lib/nebula/models/Qwen2.5-7B-Instruct-Q4_K_M.gguf \
  https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf
```

## Why not Llama 3.x?

Meta Llama 3.x models are strong for general chat but their instruction following
for structured JSON output is worse than Phi-3.5 and Qwen2.5 at equivalent sizes.
For a security agent that always outputs JSON, this matters.

## Why not Mistral 7B?

Mistral 7B was the right choice in 2024. Qwen2.5-7B is better on every benchmark
relevant to NebulaSentinel (structured output, code generation, classification).
Use Qwen2.5-7B instead.

## Performance reference

| Hardware               | Model             | Analysis time |
|------------------------|-------------------|---------------|
| 8-core Intel i7        | Phi-3.5-mini Q4   | ~12s (CPU)    |
| AMD EPYC 16-core       | Phi-3.5-mini Q4   | ~7s  (CPU)    |
| RTX 3060 12GB          | Qwen2.5-7B Q4     | ~2s  (GPU)    |
| RTX 4090               | Qwen2.5-7B Q4     | ~0.7s (GPU)   |
| Apple M2 Pro 16GB      | Phi-3.5-mini Q4   | ~2.5s (Metal) |
| Apple M2 Pro 16GB      | Qwen2.5-7B Q4     | ~4s  (Metal)  |

LLM analysis runs async — threats are forwarded immediately, analysis follows.
